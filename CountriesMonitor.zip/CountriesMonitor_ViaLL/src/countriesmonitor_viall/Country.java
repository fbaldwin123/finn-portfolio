/*
 * Finn Baldwin
 * Data Structures and Algorithms
 * DS_Ass03A1Baldwin_F
 * 10/11/2024
 */
package countriesmonitor_viall;

import javax.swing.JOptionPane;

public class Country {
    private String name;
    private long population;
    private double gni;
    private double pci;

    // Constructor
    public Country(String name, long population, double gni)
    {
        this.name = name;
        this.population = population;
        this.gni = gni;
        this.pci = gni / population;  // Compute PCI
    }

    // Getters for displaying country details
    public double getPci() 
    {
        return pci;
    }

    public String getName()
    {
        return name;
    }

    @Override
    public String toString() 
    {
        return "Country: " + name + ", Population: " + population + ", GNI: " + gni + ", PCI: " + pci;
    }
}

