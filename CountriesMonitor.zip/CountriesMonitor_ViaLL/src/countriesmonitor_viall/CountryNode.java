/*
 * Finn Baldwin
 * Data Structures and Algorithms
 * DS_Ass03A1Baldwin_F
 * 10/11/2024
 */
package countriesmonitor_viall;

public class CountryNode
{
    Country data;
    CountryNode next;

    // Constructor
    public CountryNode(Country data)
    {
        this.data = data;
        this.next = null;
    }
}