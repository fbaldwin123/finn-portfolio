/*
 * Finn Baldwin
 * Data Structures and Algorithms
 * DS_Ass03A1Baldwin_F
 * 10/11/2024
 */
package countriesmonitor_viall;

import javax.swing.JOptionPane;

public class CountryLinkedList 
{
    private CountryNode head;

    // Add a new country to the list
    public void addCountry(Country country) 
    {
        CountryNode newNode = new CountryNode(country);
        if (head == null) 
        {
            head = newNode;
        }
        else 
        {
            CountryNode current = head;
            while (current.next != null) 
            {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Remove a country by name
    public void removeCountry(String name) 
    {
        if (head == null) 
        {
            System.out.println("List is empty.");
            return;
        }

        if (head.data.getName().equals(name))
        {
            head = head.next;
            System.out.println("Country removed.");
            return;
        }

        CountryNode current = head;
        while (current.next != null && !current.next.data.getName().equals(name))
        {
            current = current.next;
        }

        if (current.next == null)
        {
            System.out.println("Country not found.");
        } else {
            current.next = current.next.next;
            System.out.println("Country removed.");
        }
    }

    // Find and display a country by name
    public void findCountry(String name)
    {
        CountryNode current = head;
        while (current != null) 
        {
            if (current.data.getName().equals(name))
            {
                System.out.println(current.data);
                return;
            }
            current = current.next;
        }
        System.out.println("Country not found.");
    }

    // Display all the countrys
    public void displayCountries()
    {
        CountryNode current = head;
        while (current != null)
        {
            System.out.println(current.data);
            current = current.next;
        }
    }

    // Sort countries by PCI
    public void sortCountriesByPCI()
    {
        if (head == null || head.next == null)
        {
            return;
        }

        boolean swapped;
        do
        {
            swapped = false;
            CountryNode current = head;
            while (current.next != null)
            {
                if (current.data.getPci() > current.next.data.getPci()) 
                {
                    // Swap countries
                    Country temp = current.data;
                    current.data = current.next.data;
                    current.next.data = temp;
                    swapped = true;
                }
                current = current.next;
            }
        } while (swapped);
    }

    // Get the size of list
    public int getSize()
    {
        int count = 0;
        CountryNode current = head;
        while (current != null)
        {
            count++;
            current = current.next;
        }
        return count;
    }

    // Empty the list
    public void emptyList() {
        head = null;
    }

    // Find the country with the highest PCI
    public Country getCountryWithHighestPCI()
    {
        if (head == null) return null;

        CountryNode current = head;
        Country highest = head.data;
        while (current != null) {
            if (current.data.getPci() > highest.getPci())
            {
                highest = current.data;
            }
            current = current.next;
        }
        return highest;
    }

    // country with the lowest PCI
    public Country getCountryWithLowestPCI()
    {
        if (head == null) return null;

        CountryNode current = head;
        Country lowest = head.data;
        while (current != null) 
        {
            if (current.data.getPci() < lowest.getPci())
            {
                lowest = current.data;
            }
            current = current.next;
        }
        return lowest;
    }
}