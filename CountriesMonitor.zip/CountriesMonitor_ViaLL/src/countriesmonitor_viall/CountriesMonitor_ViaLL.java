/*
 * Finn Baldwin
 * Data Structures and Algorithms
 * DS_Ass03A1Baldwin_F
 * 10/11/2024
 */
package countriesmonitor_viall;

import javax.swing.JOptionPane;

public class CountriesMonitor_ViaLL 
{
    private CountryLinkedList countryList;

    // Constructor
    public CountriesMonitor_ViaLL() 
    {
        countryList = new CountryLinkedList();
    }

    // Add a country using JOptionPane
    public void addCountry()
    {
        String name = JOptionPane.showInputDialog("Enter country name:");
        long population = Long.parseLong(JOptionPane.showInputDialog("Enter population:"));
        double gni = Double.parseDouble(JOptionPane.showInputDialog("Enter GNI:"));

        Country country = new Country(name, population, gni);
        countryList.addCountry(country);
    }

    // display all countries
    public void displayCountries() 
    {
        countryList.displayCountries();
    }

    // Countries PCI
    public void sortCountriesByPCI()
    {
        countryList.sortCountriesByPCI();
        JOptionPane.showMessageDialog(null, "Countries sorted by GNI.");
    }

    // remove country
    public void removeCountry() 
    {
        String name = JOptionPane.showInputDialog("Enter the name of the country to remove:");
        countryList.removeCountry(name);
    }

    // Find a country
    public void findCountry()
    {
        String name = JOptionPane.showInputDialog("Enter the name of the country to find:");
        countryList.findCountry(name);
    }

    // Size of list
    public void checkListSize()
    {
        JOptionPane.showMessageDialog(null, "List size: " + countryList.getSize());
    }

    // Empty list
    public void emptyList()
    {
        countryList.emptyList();
        JOptionPane.showMessageDialog(null, "The list has been emptied.");
    }

    public static void main(String[] args) 
    {
        CountriesMonitor_ViaLL monitor = new CountriesMonitor_ViaLL();

        while (true)
        {
            String[] options =
            {
                "Add Country", "Display Countries", "Sort by PCI", 
                "Remove Country", "Find Country", "List Size", 
                "Empty List", "Quit"
            };
            int choice = JOptionPane.showOptionDialog(null, "Choose an option", "Country Monitor",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            if (choice == 0)
            {
                monitor.addCountry();
            } 
            else if (choice == 1)
            {
                monitor.displayCountries();
            }
            else if (choice == 2)
            {
                monitor.sortCountriesByPCI();
            }
            else if (choice == 3)
            {
                monitor.removeCountry();
            }
            else if (choice == 4) 
            {
                monitor.findCountry();
            }
            else if (choice == 5) 
            {
                monitor.checkListSize();
            } 
            else if (choice == 6) 
            {
                monitor.emptyList();
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Exiting program.");
                break;
            }
        }
    }
}