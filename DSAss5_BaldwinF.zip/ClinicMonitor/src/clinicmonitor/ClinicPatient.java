/*
 * Finn Baldwin
 * Data Structures and Algorithms
 * DSAss5B
 * 11/3/2024
 */
package clinicmonitor;

public class ClinicPatient {
    protected int pNumber;
    protected String pFirstName, pLastName, pTelephone;

    // Constructor: Initializes default values
    public ClinicPatient() {
        this.pNumber = 0;
        this.pFirstName = "";
        this.pLastName = "";
        this.pTelephone = "000-000-0000";
    }

    // Modifies current object with another ClinicPatient object's details
    public void modifyMe(ClinicPatient thisOne) {
        this.pNumber = thisOne.pNumber;
        this.pFirstName = thisOne.pFirstName;
        this.pLastName = thisOne.pLastName;
        this.pTelephone = thisOne.pTelephone;
    }

    // Input data for patient, validating inputs
    public void inputData(int x) {
        String inputNumber, inputTele;

        // Accept and validate pNumber
        do {
            inputNumber = promptForID(x); // Assume promptForID() is a method to get user input for ID
        } while (!validateNumber(inputNumber));
        this.pNumber = Integer.parseInt(inputNumber);

        // Accept names
        this.pFirstName = promptForFirstName(x); // Assume promptForFirstName() gets first name input
        this.pLastName = promptForLastName(x); // Assume promptForLastName() gets last name input

        // Accept and validate telephone number
        do {
            inputTele = promptForTelephone(x); // Assume promptForTelephone() gets telephone input
        } while (!validateTele(inputTele));
        this.pTelephone = inputTele;
    }

    // Returns a formatted string for patient information
    public String printMe() {
        return "Patient: " + pNumber + " - " + pFirstName + " " + pLastName + "\n" +
               "Telephone: " + pTelephone;
    }

    // Returns the patient's ID
    public int getID() {
        return pNumber;
    }

    // Validates if the ID is numeric
    private boolean validateNumber(String thisID) {
        for (int i = 0; i < thisID.length(); i++) {
            if (!Character.isDigit(thisID.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    // Validates if the telephone number follows "000-000-0000" format
    private boolean validateTele(String thisTele) {
        if (thisTele.length() != 12) return false;
        for (int i = 0; i < thisTele.length(); i++) {
            if (i == 3 || i == 7) {
                if (thisTele.charAt(i) != '-') return false;
            } else {
                if (!Character.isDigit(thisTele.charAt(i))) return false;
            }
        }
        return true;
    }

    private String promptForFirstName(int x) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String promptForID(int x) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String promptForLastName(int x) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String promptForTelephone(int x) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
