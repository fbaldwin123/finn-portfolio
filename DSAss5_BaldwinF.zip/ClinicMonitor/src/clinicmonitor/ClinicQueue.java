/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clinicmonitor;

public class ClinicQueue {
    protected ClinicNode qFront, qRear;
    protected int qLength;

    // Constructor: Initializes queue with empty front and rear
    public ClinicQueue() {
        this.qFront = null;
        this.qRear = null;
        this.qLength = 0;
    }

    // Adds a patient at the rear of the queue
    public void addRear(ClinicPatient thisPatient) {
        ClinicNode newNode = new ClinicNode();
        newNode.nInfo.modifyMe(thisPatient);
        newNode.nNext = null;

        if (qRear == null) {
            qFront = qRear = newNode;
        } else {
            qRear.nNext = newNode;
            qRear = newNode;
        }
        qLength++;
    }

    // Removes a patient from the front of the queue
    public ClinicPatient removeFront() {
        if (qFront == null) return null;

        ClinicPatient removedPatient = qFront.nInfo;
        qFront = qFront.nNext;
        
        if (qFront == null) {
            qRear = null;
        }
        
        qLength--;
        return removedPatient;
    }

    // Returns the current size of the queue
    public int getSize() {
        return qLength;
    }

    // Clears the queue
    public void clearQueue() {
        while (qFront != null) {
            ClinicNode temp = qFront;
            qFront = qFront.nNext;
            temp = null; // Help with garbage collection
        }
        qRear = null;
        qLength = 0;
    }
    
    // Other methods can be implemented similarly, like modifying queue contents, getting info, etc.
}
