/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clinicmonitor;


public class ClinicNode {
    protected ClinicPatient nInfo;
    protected ClinicNode nNext;

    // Constructor: Initializes ClinicPatient and sets next node to null
    public ClinicNode() {
        this.nInfo = new ClinicPatient();
        this.nNext = null;
    }

    // Modifies the node's information with another node's data
    public void modifyMe(ClinicNode thisNode) {
        this.nInfo.modifyMe(thisNode.nInfo);
        this.nNext = thisNode.nNext;
    }

    // Initializes patient data
    public void inputData(int x) {
        this.nInfo.inputData(x);
        this.nNext = null;
    }

    // Returns a string with patient's information
    public String printMe() {
        return this.nInfo.printMe();
    }
}