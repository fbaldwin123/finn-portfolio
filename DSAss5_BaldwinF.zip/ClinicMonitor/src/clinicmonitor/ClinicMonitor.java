/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clinicmonitor;

import java.util.Scanner;

public class ClinicMonitor {

    static final int MAX = 10;
    static ClinicQueue[] theClinic = new ClinicQueue[MAX];
    static boolean[] openFlag = new boolean[MAX];
    static String[] theDoctor = new String[MAX];
    final static String HEADING = "The Clinic Monitor of Bruce F. Jones";
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean exitTime = false;
        int userOption;

        initialize();

        // Main Operations loop
        while (!exitTime) {
            // Display menu
            System.out.println("\n" + HEADING);
            System.out.println("1. Open Queues");
            System.out.println("2. Enqueue Patients");
            System.out.println("3. Dequeue Patients");
            System.out.println("4. List Patients");
            System.out.println("5. Reassign Patients");
            System.out.println("6. Check Queue Size");
            System.out.println("7. Empty Queue");
            System.out.println("8. Close Queue");
            System.out.println("9. Quit Processing");
            System.out.print("Please enter a menu option: ");
            
            userOption = scanner.nextInt();

            // Execute selected option
            switch (userOption) {
                case 1 -> openQueue();
                case 2 -> enqueuePatients();
                case 3 -> dequeuePatients();
                case 4 -> listPatients();
                case 5 -> reassignPatients();
                case 6 -> checkSize();
                case 7 -> emptyQueue();
                case 8 -> closeQueue();
                case 9 -> exitTime = true;
                default -> System.out.println("Invalid option. Please try again.");
            }
        }
        System.out.println("Program terminated.");
    }

    private static void initialize() {
        for (int i = 0; i < MAX; i++) {
            theClinic[i] = new ClinicQueue();
            System.out.print("Enter physician name for Doctor " + (i + 1) + ": ");
            theDoctor[i] = scanner.next();
            openFlag[i] = false; // Assume queues are closed initially
        }
    }

    private static void openQueue() {
        boolean continueFlag = true;
        while (continueFlag) {
            for (int i = 0; i < MAX; i++) {
                System.out.println((i + 1) + ": " + theDoctor[i] + " (Queue " + (openFlag[i] ? "Open" : "Closed") + ")");
            }
            System.out.print("Select a queue to open (1-" + MAX + "): ");
            int qChoice = scanner.nextInt();
            if (qChoice >= 1 && qChoice <= MAX) {
                openFlag[qChoice - 1] = true;
                System.out.println("Queue for Dr. " + theDoctor[qChoice - 1] + " is now open.");
            } else {
                System.out.println("Invalid queue number.");
            }
            System.out.print("Continue to open more queues? (Y/N): ");
            continueFlag = scanner.next().equalsIgnoreCase("Y");
        }
    }

    private static void enqueuePatients() {
        // Implementation for adding patients to a queue
    }

    private static void dequeuePatients() {
        // Implementation for removing patients from a queue
    }

    private static void listPatients() {
        // Implementation for listing patients in each queue
    }

    private static void reassignPatients() {
        // Implementation for reassigning patients from one queue to another
    }

    private static void checkSize() {
        System.out.print("Enter queue number to check size (1-" + MAX + "): ");
        int qChoice = scanner.nextInt();
        if (qChoice >= 1 && qChoice <= MAX && openFlag[qChoice - 1]) {
            int size = theClinic[qChoice - 1].getSize();
            System.out.println("Queue " + qChoice + " (Dr. " + theDoctor[qChoice - 1] + ") has " + size + " patients.");
        } else {
            System.out.println("Invalid queue number or the queue is not open.");
        }
    }

    private static void emptyQueue() {
        // Implementation for emptying a specific queue
    }

    private static void closeQueue() {
        // Implementation for closing a specific queue
    }
}
