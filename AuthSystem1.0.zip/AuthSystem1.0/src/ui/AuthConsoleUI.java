package ui;

import auth.UserDAO;
import models.User;
import util.PasswordUtil;

import java.util.Scanner;

public class AuthConsoleUI {
    private static final Scanner scanner = new Scanner(System.in);
    private static final UserDAO userDAO = new UserDAO();

    public static void start() {
        while (true) {
            System.out.println("\n=== User Authentication Menu ===");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    registerUser();
                    break;
                case "2":
                    loginUser();
                    break;
                case "3":
                    System.out.println("👋 Goodbye!");
                    return;
                default:
                    System.out.println("❌ Invalid choice.");
            }
        }
    }

    private static void registerUser() {
        System.out.println("\n--- Register User ---");

        System.out.print("Username: ");
        String username = scanner.nextLine();

        System.out.print("Email: ");
        String email = scanner.nextLine();

        System.out.print("Password: ");
        String password = scanner.nextLine();

        String hashedPassword = PasswordUtil.hashPassword(password);
        User newUser = new User(username, email, hashedPassword, "user");

        if (userDAO.registerUser(newUser)) {
            System.out.println("✅ Registration successful.");
        } else {
            System.out.println("❌ Registration failed.");
        }
    }

    private static void loginUser() {
        System.out.println("\n--- Login User ---");

        System.out.print("Username: ");
        String username = scanner.nextLine();

        System.out.print("Password: ");
        String password = scanner.nextLine();

        User user = userDAO.getUserByUsername(username);

        if (user == null) {
            System.out.println("❌ User not found.");
            return;
        }

        if (user.getFailedAttempts() >= 3) {
            System.out.println("🔒 Account is locked due to too many failed login attempts.");
            return;
        }

        if (PasswordUtil.checkPassword(password, user.getPasswordHash())) {
            user.setFailedAttempts(0); // reset
            userDAO.updateFailedAttempts(user);
            System.out.println("✅ Login successful. Welcome, " + user.getUsername() + "!");
        } else {
            int attempts = user.getFailedAttempts() + 1;
            user.setFailedAttempts(attempts);
            userDAO.updateFailedAttempts(user);

            if (attempts >= 3) {
                System.out.println("🔒 Account locked after 3 failed attempts.");
            } else {
                System.out.println("❌ Incorrect password. Attempt " + attempts + " of 3.");
            }
        }
    }
}