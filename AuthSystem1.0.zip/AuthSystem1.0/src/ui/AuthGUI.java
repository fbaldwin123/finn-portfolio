package ui;

import auth.UserDAO;
import models.User;
import util.PasswordUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class AuthGUI extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton, registerButton;
    private JLabel messageLabel;
    private final UserDAO userDAO = new UserDAO();

    public AuthGUI() {
        setTitle("User Authentication");
        setSize(350, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        usernameField = new JTextField();
        passwordField = new JPasswordField();
        loginButton = new JButton("Login");
        registerButton = new JButton("Register");
        messageLabel = new JLabel(" ", SwingConstants.CENTER);

        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        panel.add(buttonPanel);

        add(panel, BorderLayout.CENTER);
        add(messageLabel, BorderLayout.SOUTH);

        loginButton.addActionListener(this::handleLogin);
        registerButton.addActionListener(this::handleRegister);
    }

    private void handleLogin(ActionEvent e) {
        String username = usernameField.getText();
        String password = String.valueOf(passwordField.getPassword());

        User user = userDAO.getUserByUsername(username);
        if (user == null) {
            messageLabel.setText("❌ User not found.");
            return;
        }

        if (user.getFailedAttempts() >= 3) {
            messageLabel.setText("🔒 Account locked. Contact admin.");
            return;
        }

        if (PasswordUtil.checkPassword(password, user.getPasswordHash())) {
            userDAO.resetFailedAttempts(username);
            messageLabel.setText("✅ Login successful. Welcome, " + user.getUsername() + "!");
        } else {
            userDAO.increaseFailedAttempts(username);
            int attempts = user.getFailedAttempts() + 1;
            messageLabel.setText("❌ Invalid password. Attempts: " + attempts);
        }
    }

    private void handleRegister(ActionEvent e) {
        String username = usernameField.getText();
        String password = String.valueOf(passwordField.getPassword());
        String email = JOptionPane.showInputDialog(this, "Enter Email:");

        if (email == null || email.trim().isEmpty()) {
            messageLabel.setText("❌ Email required.");
            return;
        }

        String hashedPassword = PasswordUtil.hashPassword(password);
        User newUser = new User(username, email, hashedPassword, "user");

        if (userDAO.registerUser(newUser)) {
            messageLabel.setText("✅ Registration successful.");
        } else {
            messageLabel.setText("❌ Registration failed.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AuthGUI().setVisible(true));
    }
}