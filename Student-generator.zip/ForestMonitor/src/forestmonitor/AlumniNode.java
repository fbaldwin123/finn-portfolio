/**
 * Finn Baldwin
 * DS_Ass07A_BaldwinF
 * 11/29/2024
 * Data Structures and Algorithms
 * Professor Foster
 */
package forestmonitor;


public class AlumniNode {
    public Alumnus alumnus; // The alumnus object
    public AlumniNode left; // Left student
    public AlumniNode right; // Right student

    // Constructor
    public AlumniNode(Alumnus alumnus) {
        this.alumnus = alumnus;
        this.left = null;
        this.right = null;
    }

    // Getters and Setters
    public Alumnus getAlumnus() {
        return alumnus;
    }

    public void setAlumnus(Alumnus alumnus) {
        this.alumnus = alumnus;
    }

    public AlumniNode getLeft() {
        return left;
    }

    public void setLeft(AlumniNode left) {
        this.left = left;
    }

    public AlumniNode getRight() {
        return right;
    }

    public void setRight(AlumniNode right) {
        this.right = right;
    }

    // toString method
    @Override
    public String toString() {
        return alumnus.toString();
    }
}
