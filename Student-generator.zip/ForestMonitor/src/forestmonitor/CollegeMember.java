/**
 * Finn Baldwin
 * DS_Ass07A_BaldwinF
 * 11/29/2024
 * Data Structures and Algorithms
 * Professor Foster
 */
package forestmonitor;

public class CollegeMember {
    private int mID_Number;
    private String mFirstName, mLastName, mGender, mTelephone, mEmail, mDateOfBirth;
    private static final int DEFAULT_ID = 0;

    // fefault Constructor
    public CollegeMember() {
        mID_Number = DEFAULT_ID;
        mDateOfBirth = String.valueOf(DEFAULT_ID);
        mFirstName = mLastName = mGender = mTelephone = mEmail = " ";
    }

    // Overloaded Constructor
    public CollegeMember(CollegeMember thisMember) {
        mID_Number = thisMember.mID_Number;
        mLastName = thisMember.mLastName;
        mFirstName = thisMember.mFirstName;
        mGender = thisMember.mGender;
        mDateOfBirth = thisMember.mDateOfBirth;
        mEmail = thisMember.mEmail;
        mTelephone = thisMember.mTelephone;
    }

    public void modifyMe(CollegeMember thisMember) {
        mID_Number = thisMember.mID_Number;
        mLastName = thisMember.mLastName;
        mFirstName = thisMember.mFirstName;
        mGender = thisMember.mGender;
        mDateOfBirth = thisMember.mDateOfBirth;
        mEmail = thisMember.mEmail;
        mTelephone = thisMember.mTelephone;
    }

    // Accessor Method
    public int getID() {
        return mID_Number;
    }

    // Input Data Method
    public void inputData(int x, String inCategory) {
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        String inputID, inputTele, inputFName, inputLName, inputDoB;

        // Accept id
        do {
            System.out.print("Enter ID for " + inCategory + " " + x + ": ");
            inputID = scanner.nextLine();
            if (!validateID(inputID)) {
                System.out.println("ID Number must be numeric");
            }
        } while (!validateID(inputID));
        mID_Number = Integer.parseInt(inputID);

        // Accept First Name
        do {
            System.out.print("Enter First Name for " + inCategory + " " + x + ": ");
            inputFName = scanner.nextLine();
            if (!Character.isLetter(inputFName.charAt(0))) {
                System.out.println("Name must begin with a letter");
            }
        } while (!Character.isLetter(inputFName.charAt(0)));
        mFirstName = inputFName;

        // Accept Last Name
        do {
            System.out.print("Enter Last Name for " + inCategory + " " + x + ": ");
            inputLName = scanner.nextLine();
            if (!Character.isLetter(inputLName.charAt(0))) {
                System.out.println("Name must begin with a letter");
            }
        } while (!Character.isLetter(inputLName.charAt(0)));
        mLastName = inputLName;

        // Accept other fields
        System.out.print("Enter Email: ");
        mEmail = scanner.nextLine();
        System.out.print("Enter Gender: ");
        mGender = scanner.nextLine();

        do {
            System.out.print("Enter Telephone: ");
            inputTele = scanner.nextLine();
            if (!validateTele(inputTele)) {
                System.out.println("Telephone number is not in the required format");
            }
        } while (!validateTele(inputTele));
        mTelephone = inputTele;

        // Accept Date of Birth
        do {
            System.out.print("Enter Date of Birth (YYYYMMDD): ");
            inputDoB = scanner.nextLine();
            if (!validateDoB(inputDoB)) {
                System.out.println("Invalid Date of Birth");
            }
        } while (!validateDoB(inputDoB));
        mDateOfBirth = inputDoB;
    }


    public boolean validateTele(String thisTele) {
        if (thisTele.length() != 12) return false;
        for (int x = 0; x < thisTele.length(); x++) {
            if ((x == 3 || x == 7) && thisTele.charAt(x) != '-') return false;
            else if ((x != 3 && x != 7) && !Character.isDigit(thisTele.charAt(x))) return false;
        }
        return true;
    }

    public boolean validateID(String thisID) {
        for (int x = 0; x < thisID.length(); x++) {
            if (!Character.isDigit(thisID.charAt(x))) return false;
        }
        return true;
    }

    public boolean validateDoB(String thisDate) {
        if (thisDate.length() != 8) return false;
        int year = Integer.parseInt(thisDate.substring(0, 4));
        int month = Integer.parseInt(thisDate.substring(4, 6));
        int day = Integer.parseInt(thisDate.substring(6, 8));
        java.time.YearMonth yearMonth = java.time.YearMonth.of(year, month);
        return day > 0 && day <= yearMonth.lengthOfMonth();
    }

    // Print
    public String printMe() {
        return "ID Number: " + mID_Number + " Name: " + mFirstName + " " + mLastName + "\n" +
                "Gender: " + mGender + ", Date of Birth: " + mDateOfBirth + "\n" +
                "Telephone: " + mTelephone + "\n" +
                "E-Mail: " + mEmail;
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        System.gc();
    }

    @Override
    public String toString() {
        return "CollegeMember: " + printMe();
    }

    @Override
    public boolean equals(Object thisObject) {
        if (thisObject instanceof CollegeMember) {
            CollegeMember thisMember = (CollegeMember) thisObject;
            return mID_Number == thisMember.mID_Number;
        }
        return false;
    }

    void setID(int studentID) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
