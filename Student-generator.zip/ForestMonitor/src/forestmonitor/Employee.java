/**
 * Finn Baldwin
 * DS_Ass07A_BaldwinF
 * 11/29/2024
 * Data Structures and Algorithms
 * Professor Foster
 */
package forestmonitor;

import javax.swing.*;

public class Employee extends CollegeMember implements Comparable<Employee> {
    private String jobDept;
    private String jobSpecialization;
    private String jobTitle;
    private String employeeID; 

    // Constructor with CollegeMember initialization
    public Employee(String employeeID, String jobDept, String jobSpecialization, String jobTitle) {
        super(); 
        this.employeeID = employeeID;
        this.jobDept = jobDept;
        this.jobSpecialization = jobSpecialization;
        this.jobTitle = jobTitle;
    }

    // implement compare To method to compare based on employeeID
    @Override
    public int compareTo(Employee other) {
        return this.employeeID.compareTo(other.employeeID); 
    }

    // Getters and Setters for employeeID, jobDept, jobSpecialization, jobTitle
    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    public String getJobDept() {
        return jobDept;
    }

    public void setJobDept(String jobDept) {
        this.jobDept = jobDept;
    }

    public String getJobSpecialization() {
        return jobSpecialization;
    }

    public void setJobSpecialization(String jobSpecialization) {
        this.jobSpecialization = jobSpecialization;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    // Override the tostring method for display
    @Override
    public String toString() {
        return "Employee ID: " + employeeID + "\nDepartment: " + jobDept + "\nSpecialization: " + jobSpecialization + "\nTitle: " + jobTitle;
    }

    // Implement inputData method to gather employee data
    public void inputData(int x) {
        this.employeeID = JOptionPane.showInputDialog("Enter Employee ID for Employee #" + x);
        this.jobDept = JOptionPane.showInputDialog("Enter Department for Employee #" + x);
        this.jobSpecialization = JOptionPane.showInputDialog("Enter Specialization for Employee #" + x);
        this.jobTitle = JOptionPane.showInputDialog("Enter Job Title for Employee #" + x);
    }

    // Modify employee data
    void modifyData() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}