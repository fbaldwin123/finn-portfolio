/**
 * Finn Baldwin
 * DS_Ass07A_BaldwinF
 * 11/29/2024
 * Data Structures and Algorithms
 * Professor Foster
 */
package forestmonitor;


public class EmployeeBinaryTree {
    private EmployeeNode root;

    public EmployeeBinaryTree() {
        this.root = null;
    }

    // Add a new employee to the tree
    public void add(Employee employee) {
        root = addRecursive(root, employee);
    }

    private EmployeeNode addRecursive(EmployeeNode current, Employee employee) {
        if (current == null) {
            return new EmployeeNode(employee);
        }

        // Use compareTo method to compare employee IDs
        if (employee.getEmployeeID().compareTo(current.getEmployee().getEmployeeID()) < 0) {
            current.setLeft(addRecursive(current.getLeft(), employee));
        } else if (employee.getEmployeeID().compareTo(current.getEmployee().getEmployeeID()) > 0) {
            current.setRight(addRecursive(current.getRight(), employee));
        }
        return current;
    }

    // Search for an employee by ID
    public Employee search(int employeeID) {
        return searchRecursive(root, employeeID);
    }

    private Employee searchRecursive(EmployeeNode current, int employeeID) {
        if (current == null) {
            return null; 
        }

        // Convert employeeID (int) to String for comparison
        if (String.valueOf(employeeID).equals(current.getEmployee().getEmployeeID())) {
            return current.getEmployee(); 
        }

        
        return employeeID < Integer.parseInt(current.getEmployee().getEmployeeID())
                ? searchRecursive(current.getLeft(), employeeID) // search left
                : searchRecursive(current.getRight(), employeeID); // Search right
    }

    // Display employees in traversal
    public void displayInOrder() {
        displayInOrderRecursive(root);
    }

    private void displayInOrderRecursive(EmployeeNode current) {
        if (current != null) {
            displayInOrderRecursive(current.getLeft());
            System.out.println(current.getEmployee());
            displayInOrderRecursive(current.getRight());
        }
    }

    // Get the size of the tree nodes
    public int getSize() {
        return getSizeRecursive(root);
    }

    private int getSizeRecursive(EmployeeNode current) {
        if (current == null) {
            return 0;
        }
        return 1 + getSizeRecursive(current.getLeft()) + getSizeRecursive(current.getRight());
    }

    // Clear the tree
    public void clearTree() {
        root = null;
    }

    // Check if the tree is empty
    public boolean isEmpty() {
        return root == null; 
    }

    // In-order traversal 
    public void inOrderTraversal() {
        displayInOrder(); 
    }

    // Remove an employee by ID 
    public boolean remove(int employeeID) {
        // Implement the remove logic if necessary
        return false; 
    }

    // Update employee details 
    public boolean update(Employee modifyEmployee) {
        // 
        return false; 
    }

    // Traverse the tree and append results to a StringBuilder (in-order)
    public void traverseInOrder(StringBuilder result) {
        traverseInOrderRecursive(root, result);
    }

    // Recursive helper method for in-order traversal with StringBuilder
    private void traverseInOrderRecursive(EmployeeNode current, StringBuilder result) {
        if (current != null) {
            traverseInOrderRecursive(current.getLeft(), result); // Traverse left
            result.append(current.getEmployee()).append("\n");   // Append the current employee's data
            traverseInOrderRecursive(current.getRight(), result); // Traverse right
        }
    }

    // Remove unsupported method placeholders
    // These methods throw exceptions because they are not implemented or not needed.
    String size() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    void clear() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}