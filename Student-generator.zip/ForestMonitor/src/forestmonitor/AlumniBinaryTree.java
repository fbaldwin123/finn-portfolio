/**
 * Finn Baldwin
 * DS_Ass07A_BaldwinF
 * 11/29/2024
 * Data Structures and Algorithms
 * Professor Foster
 */
package forestmonitor;

public class AlumniBinaryTree {
    private AlumniNode root;

    public AlumniBinaryTree() {
        this.root = null;
    }

    // Add a new alumnus to the tree
    public void add(Alumnus alumnus) {
        root = addRecursive(root, alumnus);
    }

    // Helper method to recursively add a new alumnus node
    private AlumniNode addRecursive(AlumniNode current, Alumnus alumnus) {
        if (current == null) {
            return new AlumniNode(alumnus);
        }

        if (alumnus.getAlumniID().compareTo(current.getAlumnus().getAlumniID()) < 0) {
            current.setLeft(addRecursive(current.getLeft(), alumnus));
        } else if (alumnus.getAlumniID().compareTo(current.getAlumnus().getAlumniID()) > 0) {
            current.setRight(addRecursive(current.getRight(), alumnus));
        }
        return current;
    }

    // Search for an alumnus by ID
    public Alumnus search(String alumniID) {
        return searchRecursive(root, alumniID);
    }

    // Helper method to search for an alumnus recursively
    private Alumnus searchRecursive(AlumniNode current, String alumniID) {
        if (current == null) {
            return null;
        }

        // If the current node's alumni ID matches the search ID, return the alumnus
        if (alumniID.equals(current.getAlumnus().getAlumniID())) {
            return current.getAlumnus();
        }

        // Recursively search in the left or right subtree based on the comparison
        return alumniID.compareTo(current.getAlumnus().getAlumniID()) < 0
                ? searchRecursive(current.getLeft(), alumniID)
                : searchRecursive(current.getRight(), alumniID);
    }

    // Display alumni in in-order traversal
    public void displayInOrder() {
        displayInOrderRecursive(root);
    }

    // Helper method to recursively display alumni
    private void displayInOrderRecursive(AlumniNode current) {
        if (current != null) {
            displayInOrderRecursive(current.getLeft());
            System.out.println(current.getAlumnus());
            displayInOrderRecursive(current.getRight());
        }
    }

    // Clears the tree by setting root to null
    public void clearTree() {
        root = null;  // Clear the tree
    }

    // Get the size of the tree
    public int getSize() {
        return getSizeRecursive(root);
    }

    // Helper method to recursively count the nodes in the tree
    private int getSizeRecursive(AlumniNode current) {
        if (current == null) {
            return 0;
        }
        return 1 + getSizeRecursive(current.getLeft()) + getSizeRecursive(current.getRight());
    }

    // Implementation of isEmpty() to check if the tree is empty
    public boolean isEmpty() {
        return root == null;
    }

    // Traverse in-order and append results to a StringBuilder
    public void traverseInOrder(StringBuilder result) {
        traverseInOrderRecursive(root, result);
    }

    // Recursive helper method for in-order traversal with StringBuilder
    private void traverseInOrderRecursive(AlumniNode current, StringBuilder result) {
        if (current != null) {
            traverseInOrderRecursive(current.getLeft(), result); // Traverse left
            result.append(current.getAlumnus()).append("\n");   // Append the current node's alumni data
            traverseInOrderRecursive(current.getRight(), result); // Traverse right
        }
    }

    // Other methods removed for brevity
    void clear() {
        // Implement clear logic if necessary
    }

    String size() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    void inOrderTraversal() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    void update(Alumnus modifyAlumni) {
        // Implement update logic for modifying an alumnus if needed
    }

    // Removed unsupported search method
    // Removed the method 'Alumnus search(int modifyID)'
    
    boolean remove(int removeID) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}