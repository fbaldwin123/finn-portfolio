/**
 * Finn Baldwin
 * DS_Ass07A_BaldwinF
 * 11/29/2024
 * Data Structures and Algorithms
 * Professor Foster
 */
package forestmonitor;


public class StudentNode implements Comparable<StudentNode> {
    public Student student; // The student object stored in this node
    public StudentNode left; // Left child
    public StudentNode right; // Right child

    // Constructor
    public StudentNode(Student student) {
        this.student = student;
        this.left = null;
        this.right = null;
    }

    // Getters and Setters
    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public StudentNode getLeft() {
        return left;
    }

    public void setLeft(StudentNode left) {
        this.left = left;
    }

    public StudentNode getRight() {
        return right;
    }

    public void setRight(StudentNode right) {
        this.right = right;
    }

    // toString method
    @Override
    public String toString() {
        return student.toString();
    }

    // compareTo Method
    @Override
    public int compareTo(StudentNode other) {
        
        return this.student.compareTo(other.student);
    }

    class nInfo {

        static Object printMe() {
            throw new UnsupportedOperationException("Not supported yet."); 
        }

        public nInfo() {
        }
    }
}