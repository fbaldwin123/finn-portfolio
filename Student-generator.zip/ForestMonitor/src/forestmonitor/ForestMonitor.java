/**
 * Finn Baldwin
 * DS_Ass07A_BaldwinF
 * 11/29/2024
 * Data Structures and Algorithms
 * Professor Foster
 */
package forestmonitor;


import javax.swing.JOptionPane;

public class ForestMonitor {
    static StudentBinaryTree BS_Tree1;
    static AlumniBinaryTree BS_Tree2;
    static EmployeeBinaryTree BS_Tree3;

    final static String HEADING = "The College Forest of Bruce F. Jones";

    public static void main(String[] args) {
        initialize();
        boolean exitTime = false;
        int option;

        while (!exitTime) {
            String menu = HEADING + "\n" +
                    "1. Enter Students Info\n" +
                    "2. Enter Alumni Info\n" +
                    "3. Enter Employees Info\n" +
                    "4. Query Students Info\n" +
                    "5. Query Alumni Info\n" +
                    "6. Query Employees Info\n" +
                    "7. Remove Students Info\n" +
                    "8. Remove Alumni Info\n" +
                    "9. Remove Employees Info\n" +
                    "10. Modify Students Info\n" +
                    "11. Modify Alumni Info\n" +
                    "12. Modify Employees Info\n" +
                    "13. Traverse Students Tree\n" +
                    "14. Traverse Alumni Tree\n" +
                    "15. Traverse Employees Tree\n" +
                    "16. Check Tree Size\n" +
                    "17. Empty Tree\n" +
                    "90. Exit";
            try {
                option = Integer.parseInt(JOptionPane.showInputDialog(menu));
            } catch (NumberFormatException e) {
                continue;
            }

            switch (option) {
                case 1 -> inputStudents();
                case 2 -> inputAlumni();
                case 3 -> inputEmployees();
                case 4 -> queryStudents();
                case 5 -> queryAlumni();
                case 6 -> queryEmployees();
                case 7 -> removeStudents();
                case 8 -> removeAlumni();
                case 9 -> removeEmployees();
                case 10 -> modifyStudents();
                case 11 -> modifyAlumni();
                case 12 -> modifyEmployees();
                case 13 -> traverseStudents();
                case 14 -> traverseAlumni();
                case 15 -> traverseEmployees();
                case 16 -> checkTreeSize();
                case 17 -> emptyTree();
                case 90 -> exitTime = true;
                default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }

    private static void initialize() {
        BS_Tree1 = new StudentBinaryTree();
        BS_Tree2 = new AlumniBinaryTree();
        BS_Tree3 = new EmployeeBinaryTree();
    }

    public static void inputStudents() {
        int limit = Integer.parseInt(JOptionPane.showInputDialog("Enter number of students:"));
        for (int x = 1; x <= limit; x++) {
            Student currentStud = new Student();
            currentStud.inputData(x);
            BS_Tree1.add(currentStud);  // Use add method instead of insert
        }
    }

    public static void inputAlumni() {
        int limit = Integer.parseInt(JOptionPane.showInputDialog("Enter number of alumni:"));
        for (int x = 1; x <= limit; x++) {
            Alumnus currentAlumnus = new Alumnus();
            currentAlumnus.inputData(x);
            BS_Tree2.add(currentAlumnus);  // Use add method instead of insert
        }
    }

    public static void inputEmployees() {
        int limit = Integer.parseInt(JOptionPane.showInputDialog("Enter number of employees:"));
        for (int x = 1; x <= limit; x++) {
            Employee currentEmployee = new Employee("EMP001", "HR", "Recruiting", "Manager");
            currentEmployee.inputData(x);
            BS_Tree3.add(currentEmployee);  // Use add method instead of insert
        }
    }

    public static void queryStudents() {
        if (!BS_Tree1.isEmpty()) {
            boolean continueQuery = true;
            while (continueQuery) {
                int searchArg = Integer.parseInt(JOptionPane.showInputDialog("Enter Student ID:"));
                Student foundStud = BS_Tree1.search(searchArg);

                if (foundStud != null) {
                    JOptionPane.showMessageDialog(null, foundStud.printMe());
                } else {
                    JOptionPane.showMessageDialog(null, "Student is not in the tree.");
                }

                continueQuery = JOptionPane.showConfirmDialog(null, "Continue querying?") == JOptionPane.YES_OPTION;
            }
        } else {
            JOptionPane.showMessageDialog(null, "Student tree is empty.");
        }
    }

    public static void queryAlumni() {
        if (!BS_Tree2.isEmpty()) {
            boolean continueQuery = true;
            while (continueQuery) {
                String searchArg = JOptionPane.showInputDialog("Enter Alumni ID:");
                Alumnus foundAlumni = BS_Tree2.search(searchArg);

                if (foundAlumni != null) {
                    JOptionPane.showMessageDialog(null, foundAlumni.printMe());
                } else {
                    JOptionPane.showMessageDialog(null, "Alumnus is not in the tree.");
                }

                continueQuery = JOptionPane.showConfirmDialog(null, "Continue querying?") == JOptionPane.YES_OPTION;
            }
        } else {
            JOptionPane.showMessageDialog(null, "Alumni tree is empty.");
        }
    }

    public static void queryEmployees() {
        if (!BS_Tree3.isEmpty()) {
            boolean continueQuery = true;
            while (continueQuery) {
                int searchArg = Integer.parseInt(JOptionPane.showInputDialog("Enter Employee ID:"));
                Employee foundEmployee = BS_Tree3.search(searchArg);

                if (foundEmployee != null) {
                    JOptionPane.showMessageDialog(null, foundEmployee.printMe());
                } else {
                    JOptionPane.showMessageDialog(null, "Employee is not in the tree.");
                }

                continueQuery = JOptionPane.showConfirmDialog(null, "Continue querying?") == JOptionPane.YES_OPTION;
            }
        } else {
            JOptionPane.showMessageDialog(null, "Employee tree is empty.");
        }
    }

    public static void removeStudents() {
        if (!BS_Tree1.isEmpty()) {
            int removeID = Integer.parseInt(JOptionPane.showInputDialog("Enter Student ID to remove:"));
            boolean removed = BS_Tree1.remove(removeID);
            if (removed) {
                JOptionPane.showMessageDialog(null, "Student removed.");
            } else {
                JOptionPane.showMessageDialog(null, "Student not found.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Student tree is empty.");
        }
    }

    public static void removeAlumni() {
        if (!BS_Tree2.isEmpty()) {
            int removeID = Integer.parseInt(JOptionPane.showInputDialog("Enter Alumni ID to remove:"));
            boolean removed = BS_Tree2.remove(removeID);
            if (removed) {
                JOptionPane.showMessageDialog(null, "Alumnus removed.");
            } else {
                JOptionPane.showMessageDialog(null, "Alumnus not found.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Alumni tree is empty.");
        }
    }

    public static void removeEmployees() {
        if (!BS_Tree3.isEmpty()) {
            int removeID = Integer.parseInt(JOptionPane.showInputDialog("Enter Employee ID to remove:"));
            boolean removed = BS_Tree3.remove(removeID);
            if (removed) {
                JOptionPane.showMessageDialog(null, "Employee removed.");
            } else {
                JOptionPane.showMessageDialog(null, "Employee not found.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Employee tree is empty.");
        }
    }

    public static void modifyStudents() {
        if (!BS_Tree1.isEmpty()) {
            int modifyID = Integer.parseInt(JOptionPane.showInputDialog("Enter Student ID to modify:"));
            Student modifyStud = BS_Tree1.search(modifyID);
            if (modifyStud != null) {
                modifyStud.modifyData();
                BS_Tree1.update(modifyStud);
                JOptionPane.showMessageDialog(null, "Student information updated.");
            } else {
                JOptionPane.showMessageDialog(null, "Student not found.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Student tree is empty.");
        }
    }

    public static void modifyAlumni() {
        if (!BS_Tree2.isEmpty()) {
            String modifyID = JOptionPane.showInputDialog("Enter Alumni ID to modify:");
            Alumnus modifyAlumni = BS_Tree2.search(modifyID);
            if (modifyAlumni != null) {
                modifyAlumni.modifyData();
                BS_Tree2.update(modifyAlumni);
                JOptionPane.showMessageDialog(null, "Alumni information updated.");
            } else {
                JOptionPane.showMessageDialog(null, "Alumni not found.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Alumni tree is empty.");
        }
    }

    public static void modifyEmployees() {
        if (!BS_Tree3.isEmpty()) {
            int modifyID = Integer.parseInt(JOptionPane.showInputDialog("Enter Employee ID to modify:"));
            Employee modifyEmployee = BS_Tree3.search(modifyID);
            if (modifyEmployee != null) {
                modifyEmployee.modifyData();
                BS_Tree3.update(modifyEmployee);
                JOptionPane.showMessageDialog(null, "Employee information updated.");
            } else {
                JOptionPane.showMessageDialog(null, "Employee not found.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Employee tree is empty.");
        }
    }

    public static void traverseStudents() {
        if (!BS_Tree1.isEmpty()) {
            StringBuilder result = new StringBuilder();
            BS_Tree1.traverseInOrder(result);
            JOptionPane.showMessageDialog(null, result.toString());
        } else {
            JOptionPane.showMessageDialog(null, "Student tree is empty.");
        }
    }

    public static void traverseAlumni() {
        if (!BS_Tree2.isEmpty()) {
            StringBuilder result = new StringBuilder();
            BS_Tree2.traverseInOrder(result);
            JOptionPane.showMessageDialog(null, result.toString());
        } else {
            JOptionPane.showMessageDialog(null, "Alumni tree is empty.");
        }
    }

    public static void traverseEmployees() {
        if (!BS_Tree3.isEmpty()) {
            StringBuilder result = new StringBuilder();
            BS_Tree3.traverseInOrder(result);
            JOptionPane.showMessageDialog(null, result.toString());
        } else {
            JOptionPane.showMessageDialog(null, "Employee tree is empty.");
        }
    }

    public static void checkTreeSize() {
        JOptionPane.showMessageDialog(null, "Student tree size: " + BS_Tree1.size());
        JOptionPane.showMessageDialog(null, "Alumni tree size: " + BS_Tree2.size());
        JOptionPane.showMessageDialog(null, "Employee tree size: " + BS_Tree3.size());
    }

    public static void emptyTree() {
        BS_Tree1.clear();
        BS_Tree2.clear();
        BS_Tree3.clear();
        JOptionPane.showMessageDialog(null, "All trees have been cleared.");
    }
}