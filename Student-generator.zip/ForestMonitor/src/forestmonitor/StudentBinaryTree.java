/**
 * Finn Baldwin
 * DS_Ass07A_BaldwinF
 * 11/29/2024
 * Data Structures and Algorithms
 * Professor Foster
 */
package forestmonitor;


public class StudentBinaryTree {
    private StudentNode root;

    public StudentBinaryTree() {
        this.root = null;
    }

    // Add a new student to the tree
    public void add(Student student) {
        root = addRecursive(root, student);
    }

    private StudentNode addRecursive(StudentNode current, Student student) {
        if (current == null) {
            return new StudentNode(student);
        }

        // Use the compareTo method for comparison
        if (student.compareTo(current.getStudent()) < 0) {
            current.setLeft(addRecursive(current.getLeft(), student));
        } else if (student.compareTo(current.getStudent()) > 0) {
            current.setRight(addRecursive(current.getRight(), student));
        }
        return current;
    }

    // Search for a student by ID
    public Student search(int studentID) {
        return searchRecursive(root, studentID);
    }

    private Student searchRecursive(StudentNode current, int studentID) {
        if (current == null) {
            return null;
        }

       
        if (studentID == current.getStudent().getID()) {
            return current.getStudent();
        }

        return studentID < current.getStudent().getID()
                ? searchRecursive(current.getLeft(), studentID)
                : searchRecursive(current.getRight(), studentID);
    }

    // Display students in the traversal
    public void displayInOrder() {
        StringBuilder output = new StringBuilder();
        inOrderTraversal(root, output);
        System.out.println(output.toString());
    }

    // In order traversal that accepts StudentNode type
    public void inOrderTraversal(StudentNode node, StringBuilder output) {
        if (node != null) {
            // Traverse left subtree
            inOrderTraversal(node.getLeft(), output);
            
            // Process the current node
            output.append(node.getStudent()).append("\n");
            
            // Traverse right subtree
            inOrderTraversal(node.getRight(), output);
        }
    }

    // New traverseInOrder method (this is your required change)
    public void traverseInOrder(StringBuilder result) {
        traverseInOrderRecursive(root, result);
    }

    // Recursive helper method for in-order traversal with StringBuilder
    private void traverseInOrderRecursive(StudentNode current, StringBuilder result) {
        if (current != null) {
            traverseInOrderRecursive(current.getLeft(), result); // Traverse 
            result.append(current.getStudent()).append("\n");   // Append data
            traverseInOrderRecursive(current.getRight(), result); // Traverse right
        }
    }

    // Delete a student by ID
    public void delete(int studentID) {
        root = deleteRecursive(root, studentID);
    }

    private StudentNode deleteRecursive(StudentNode current, int studentID) {
        if (current == null) {
            return null;
        }

        if (studentID < current.getStudent().getID()) {
            current.setLeft(deleteRecursive(current.getLeft(), studentID));
        } else if (studentID > current.getStudent().getID()) {
            current.setRight(deleteRecursive(current.getRight(), studentID));
        } else {
            

            
            if (current.getLeft() == null) {
                return current.getRight();
            } else if (current.getRight() == null) {
                return current.getLeft();
            }

            // Node with two children
            current.setStudent(minValue(current.getRight()));

            // Delete inorder successor
            current.setRight(deleteRecursive(current.getRight(), current.getStudent().getID()));
        }
        return current;
    }

    private Student minValue(StudentNode root) {
        // Get the leftmost leaf node
        if (root.getLeft() == null) {
            return root.getStudent();
        }
        return minValue(root.getLeft());
    }

   
    public boolean isEmpty() {
        return root == null; 
    }

    // Implement the size method to return the number of nodes
    public int getSize() {
        return getSizeRecursive(root);
    }

    private int getSizeRecursive(StudentNode current) {
        if (current == null) {
            return 0;
        }
        return 1 + getSizeRecursive(current.getLeft()) + getSizeRecursive(current.getRight());
    }

    // Implement the clearTree method
    public void clearTree() {
        root = null; 
    }

    // Implement the update method (if needed for modifying student details)
    public void update(Student modifyStud) {
        delete(modifyStud.getID());
        add(modifyStud);
    }

    // Remove student by ID (alias for delete)
    public boolean remove(int studentID) {
        delete(studentID);
        return true;
    }

    // Implement the size method
    public String size() {
        return Integer.toString(getSize()); 
    }

    // Implement the clear method
    public void clear() {
        clearTree(); 
    }
}