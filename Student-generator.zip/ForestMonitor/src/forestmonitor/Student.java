/**
 * Finn Baldwin
 * DS_Ass07A_BaldwinF
 * 11/29/2024
 * Data Structures and Algorithms
 * Professor Foster
 */
package forestmonitor;


public class Student extends CollegeMember implements Comparable<Student> {
    private String major;
    private double gpa;
    private int credits;

    // Constructor using CollegeMember
    public Student(CollegeMember thisMember) {
        super(thisMember); 
        this.major = "";
        this.gpa = 0.0;
        this.credits = 0;
    }

    // Constructor with student ID
    public Student(int studentID) {
        super(); 
        this.setID(studentID); 
        this.major = "";
        this.gpa = 0.0;
        this.credits = 0;
    }

    // Default constructor
    public Student() {
        super(); 
        this.major = "";
        this.gpa = 0.0;
        this.credits = 0;
    }

    // Method to modify student data with arguments
    public void modifyData(String newMajor, double newGpa, int newCredits) {
        
        if (newMajor != null && !newMajor.isEmpty()) {
            this.major = newMajor;
        }
        if (newGpa >= 0.0 && newGpa <= 4.0) {
            this.gpa = newGpa;
        }
        if (newCredits >= 0) {
            this.credits = newCredits;
        }
    }

    // Overloaded method to modify student data without arguments
    public void modifyData() {
        
        this.major = javax.swing.JOptionPane.showInputDialog("Enter major for the Student:");

        boolean validInput = false;
        do {
            try {
                this.gpa = Double.parseDouble(javax.swing.JOptionPane.showInputDialog("Enter GPA for the Student:"));
                if (this.gpa >= 0.0 && this.gpa <= 4.0) {
                    validInput = true;
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "GPA must be between 0.0 and 4.0. Try again.");
                }
            } catch (NumberFormatException e) {
                javax.swing.JOptionPane.showMessageDialog(null, "Invalid input. GPA must be a number. Try again.");
            }
        } while (!validInput);

        validInput = false;
        do {
            try {
                this.credits = Integer.parseInt(javax.swing.JOptionPane.showInputDialog("Enter completed credits for the Student:"));
                if (this.credits >= 0) {
                    validInput = true;
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "Credits cannot be negative. Try again.");
                }
            } catch (NumberFormatException e) {
                javax.swing.JOptionPane.showMessageDialog(null, "Invalid input. Credits must be a positive integer. Try again.");
            }
        } while (!validInput);
    }

    // Method to modify student data using another Student's data
    public void modifyMe(Student thisStudent) {
        super.modifyMe(thisStudent); 
        this.major = thisStudent.major;
        this.gpa = thisStudent.gpa;
        this.credits = thisStudent.credits;
    }

    // Input data for student
    public void inputData(int x) {
        super.inputData(x, "Student");
        this.major = javax.swing.JOptionPane.showInputDialog("Enter major for Student " + x + ":");
        boolean validInput = false;
        do {
            try {
                this.gpa = Double.parseDouble(javax.swing.JOptionPane.showInputDialog("Enter GPA for Student " + x + ":"));
                if (this.gpa >= 0.0 && this.gpa <= 4.0) {
                    validInput = true;
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "GPA must be between 0.0 and 4.0. Try again.");
                }
            } catch (NumberFormatException e) {
                javax.swing.JOptionPane.showMessageDialog(null, "Invalid input. GPA must be a number. Try again.");
            }
        } while (!validInput);

        validInput = false;
        do {
            try {
                this.credits = Integer.parseInt(javax.swing.JOptionPane.showInputDialog("Enter completed credits for Student " + x + ":"));
                if (this.credits >= 0) {
                    validInput = true;
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "Credits cannot be negative. Try again.");
                }
            } catch (NumberFormatException e) {
                javax.swing.JOptionPane.showMessageDialog(null, "Invalid input. Credits must be a positive integer. Try again.");
            }
        } while (!validInput);
    }

    // Print student data
    @Override
    public String printMe() {
        return super.printMe() + "\nMajor: " + major + "\nGPA: " + gpa + "\nCredits: " + credits;
    }

    // Finalize student object
    @Override
    protected void finalize() throws Throwable {
        System.out.println("Student object is being destroyed.");
        super.finalize(); 
    }

    // ToString method
    @Override
    public String toString() {
        return "Student: " + this.printMe();
    }

    // Equals method
    @Override
    public boolean equals(Object thisObject) {
        boolean instanceMatch = false;
        if (thisObject instanceof Student) {
            Student thisStudent = (Student) thisObject;
            if (this.getID() == thisStudent.getID()) {
                instanceMatch = true;
            }
        }
        return instanceMatch;
    }

    // Method to get the student ID
    public int getStudentID() {
        return this.getID(); 
    }

    // Compare method for Comparable interface
    @Override
    public int compareTo(Student other) {
        return Integer.compare(this.getID(), other.getID());
    }

    @Override
    void setID(int studentID) {
        
        super.setID(studentID); 
    }
}