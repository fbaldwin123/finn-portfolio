/**
 * Finn Baldwin
 * DS_Ass07A_BaldwinF
 * 11/29/2024
 * Data Structures and Algorithms
 * Professor Foster
 */
package forestmonitor;


public class EmployeeNode implements Comparable<EmployeeNode> {
    public Employee employee; 
    public EmployeeNode left; // Left stud
    public EmployeeNode right; // Right student

    // Constructor
    public EmployeeNode(Employee employee) {
        this.employee = employee;
        this.left = null;
        this.right = null;
    }

    // Getters and Setters
    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public EmployeeNode getLeft() {
        return left;
    }

    public void setLeft(EmployeeNode left) {
        this.left = left;
    }

    public EmployeeNode getRight() {
        return right;
    }

    public void setRight(EmployeeNode right) {
        this.right = right;
    }

    // toString method
    @Override
    public String toString() {
        return employee.toString();
    }

    // compareTo method to compare EmployeeNode objects based on the employees ID
    @Override
    public int compareTo(EmployeeNode other) {
        
        return Integer.compare(this.employee.getID(), other.employee.getID());
    }
}