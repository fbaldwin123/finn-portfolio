/**
 * Finn Baldwin
 * DS_Ass07A_BaldwinF
 * 11/29/2024
 * Data Structures and Algorithms
 * Professor Foster
 */
package forestmonitor;


public class Alumnus implements Comparable<Alumnus> {
    private String alumniID;  
    private String name;      

    // Constructor that takes alumniID and name
    public Alumnus(String alumniID, String name) {
        this.alumniID = alumniID;
        this.name = name;
    }

    // Default constructor 
    public Alumnus() {
        
        this.alumniID = "";
        this.name = "";
    }

    // Getter and Setter methods for alumniID and name
    public String getAlumniID() {
        return alumniID;
    }

    public void setAlumniID(String alumniID) {
        this.alumniID = alumniID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Implement compareTo method to compare by alumniID
    @Override
    public int compareTo(Alumnus other) {
        return this.alumniID.compareTo(other.alumniID);  // Compare based on alumniID
    }

    // Override toString method for display
    @Override
    public String toString() {
        return "Alumnus ID: " + alumniID + ", Name: " + name;
    }

    // Input data for an Alumnus object
    public void inputData(int x) {
        // Use JOptionPane for user input
        this.alumniID = javax.swing.JOptionPane.showInputDialog("Enter Alumni ID for Alumnus " + x + ":");
        this.name = javax.swing.JOptionPane.showInputDialog("Enter Name for Alumnus " + x + ":");
    }

  
    public void modifyData() {
        
        String newName = javax.swing.JOptionPane.showInputDialog("Enter new name for " + this.name + ":");
        if (newName != null && !newName.trim().isEmpty()) {
            this.name = newName;  
        } else {
            javax.swing.JOptionPane.showMessageDialog(null, "Name cannot be empty.");
        }
    }

    Object printMe() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}